package com.example.info;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView tvSteps;
    private ProgressBar progressBar;
    private SensorManager sensorManager;
    private Sensor stepSensor;
    private SharedPreferences prefs;
    private int stepGoal = 10000;
    private float initialStepCount = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSteps = findViewById(R.id.tv_steps);
        progressBar = findViewById(R.id.progressBar);
        Button btnSetGoal = findViewById(R.id.btn_set_goal);

        prefs = getSharedPreferences("stepPrefs", MODE_PRIVATE);
        stepGoal = prefs.getInt("stepGoal", 10000);
        progressBar.setMax(stepGoal);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        btnSetGoal.setOnClickListener(v -> showGoalDialog());
    }

    private void showGoalDialog() {
        final String[] values = {"5000", "8000", "10000", "15000"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Step Goal")
                .setItems(values, (dialog, which) -> {
                    stepGoal = Integer.parseInt(values[which]);
                    progressBar.setMax(stepGoal);
                    prefs.edit().putInt("stepGoal", stepGoal).apply();
                    Toast.makeText(this, "Goal set to " + stepGoal, Toast.LENGTH_SHORT).show();
                }).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (stepSensor != null) {
            sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (initialStepCount == -1) {
            initialStepCount = event.values[0];
        }
        int stepsToday = (int) (event.values[0] - initialStepCount);
        tvSteps.setText("Steps: " + stepsToday);
        progressBar.setProgress(stepsToday);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // No action needed
    }
}
